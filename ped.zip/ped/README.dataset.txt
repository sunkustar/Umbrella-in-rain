# Pedestrian Detection > 2023-03-27 11:50pm
https://universe.roboflow.com/training-data-kgqsn/pedestrian-detection-v6aln

Provided by a Roboflow user
License: CC BY 4.0

