# umbrella person > 2023-03-31 2:25pm
https://universe.roboflow.com/leon-4i0gq/umbrella-person

Provided by a Roboflow user
License: CC BY 4.0

